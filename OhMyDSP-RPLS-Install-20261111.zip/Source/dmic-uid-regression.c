#include <assert.h>
#include <stdio.h>
#include "OhMyDSP-main/ohmydsp/userspace/driver/OhMyDSPDriver.c"

int main(void)
{
    AudioObjectPropertyAddress a = { kAudioPlugInPropertyTranslateUIDToDevice,
        kAudioObjectPropertyScopeGlobal, kAudioObjectPropertyElementMain };
    UInt32 id = 99, size = 0;
    CFStringRef uid = CFSTR("com.ohmydsp.InternalMicrophone");
    Ctx c = { sizeof id, &size, &id, false, sizeof uid, &uid };
    assert(getProp(kObjPlugIn, &a, &c) == 0 && id == kObjDevice && size == sizeof id);
    uid = CFSTR("AppleHDAEngineOutput:1F,3,0,1,1:0");
    assert(getProp(kObjPlugIn, &a, &c) == 0 && id == kAudioObjectUnknown);
    uid = CFSTR("another.microphone");
    assert(getProp(kObjPlugIn, &a, &c) == 0 && id == kAudioObjectUnknown);
    uid = NULL;
    assert(getProp(kObjPlugIn, &a, &c) == kAudioHardwareIllegalOperationError);
    c.qSize = 0;
    assert(getProp(kObjPlugIn, &a, &c) == kAudioHardwareBadPropertySizeError);
    c.sizeOnly = true;
    c.qData = NULL;
    assert(getProp(kObjPlugIn, &a, &c) == 0 && size == sizeof id);
    puts("UID routing: known, foreign, null, malformed and size-only queries passed; no audio opened.");
    return 0;
}
