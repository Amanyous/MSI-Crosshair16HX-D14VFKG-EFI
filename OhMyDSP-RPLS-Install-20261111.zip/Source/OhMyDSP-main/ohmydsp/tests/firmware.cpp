#include "../src/FirmwareManifest.hpp"
#include "../src/CaptureSwitch.hpp"
#include <cassert>
#include <fstream>
#include <iterator>
#include <vector>
#include <iostream>

static std::vector<uint8_t> load(const char *path)
{
    std::ifstream in(path, std::ios::binary);
    assert(in);
    return {std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>()};
}
static void put(std::vector<uint8_t> &v, size_t at, uint32_t value)
{
    for (unsigned i = 0; i < 4; ++i) v.at(at + i) = uint8_t(value >> (8 * i));
}
int main()
{
    using namespace OhMyDSPPlatform;
    const auto original = load("../../../linux-payloads/sof-rpl-s.ri");
    FirmwareManifest m;
    assert(parseFirmware(original.data(), original.size(), 447232, 0x100000, m));
    assert(m.payloadOffset == 0x300 && m.payloadBytes == 446464);
    assert(m.downbox == 0xa0000 && m.downSize == 0x2000);
    assert(m.upbox == 0x81000 && m.upSize == 0x1000);
    for (size_t i = 0; i < 0x304; ++i)
        assert(!parseFirmware(original.data(), i, 447232, 0x100000, m));
    for (const auto &change : std::vector<std::pair<size_t, uint32_t>>{
             {4, 0xffffffff}, {8, 0}, {8, 0xfffffffc}, {0x14, 0},
             {0x14, 0xffffffff}, {0x24, 0xffffffff},
             {0x30, 0xffffffff}, {0x38, 0xffffffff}, {0x300, 0}}) {
        auto bad = original;
        put(bad, change.first, change.second);
        if (parseFirmware(bad.data(), bad.size(), 447232, 0x100000, m)) {
            std::cerr << "unexpectedly accepted mutation at " << std::hex << change.first << "\n";
            assert(false);
        }
    }
    assert(!parseFirmware(original.data(), original.size(), 447232, 0xa0010, m));
    const auto blob = load("../../../rpls-dmic-p10.ipc");
    uint32_t control[27] {};
    assert(buildRplsCaptureSwitch(blob.data(), blob.size(), control));
    assert(control[3] == 51 && control[5] == 2 && control[6] == 1);
    assert(control[23] == 0 && control[24] == 1 && control[25] == 1 && control[26] == 1);
    for (size_t n = 0; n < blob.size(); ++n)
        assert(!buildRplsCaptureSwitch(blob.data(), n, control));
    auto bad = blob;
    put(bad, 4, 20);
    assert(!buildRplsCaptureSwitch(bad.data(), bad.size(), control));
    std::cout << "PASS: real RPL firmware manifest bounds and stereo switch construction\n";
}
