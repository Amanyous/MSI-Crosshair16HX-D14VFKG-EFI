#include "../src/LoaderTransaction.hpp"
#include <cassert>
#include <string>

struct Fake {
    int operation = 0, failAt = -1;
    bool stuck = false;
    std::string trace;
    bool step(char c) { trace += c; return ++operation != failAt; }
    bool preflight() { return step('p'); }
    bool snapshot() { return step('s'); }
    bool prepareIccmax() { return step('i'); }
    bool prepareLoader() { return step('l'); }
    bool startCore0() { return step('c'); }
    bool transferFirmware() { return step('t'); }
    bool waitFirmwareReady() { return step('w'); }
    bool stopAndRestoreLoader() { trace += 'L'; return !stuck; }
    bool stopAndRestoreIccmax() { trace += 'I'; return !stuck; }
    bool restoreGuardband() { return step('g'); }
    bool stopCore0() { trace += 'C'; return true; }
    bool restoreSnapshot() { trace += 'S'; return true; }
};

int main()
{
    using OhMyDSPPlatform::LoaderTransaction;
    for (int failure = 1; failure <= 8; ++failure) {
        Fake hw;
        hw.failAt = failure;
        LoaderTransaction<Fake> tx(hw);
        assert(!tx.boot());
        assert(!tx.firmwareReady());
        if (failure >= 3) assert(hw.trace.back() == 'S');
        auto before = hw.trace;
        assert(tx.cleanup());
        assert(hw.trace == before);
        assert(!tx.boot());
    }
    Fake hw;
    LoaderTransaction<Fake> tx(hw);
    assert(tx.boot() && tx.firmwareReady());
    assert(hw.trace == "psilctwLIg");
    assert(tx.cleanup() && !tx.firmwareReady());
    assert(hw.trace == "psilctwLIgCS");

    Fake blocked;
    blocked.stuck = true;
    LoaderTransaction<Fake> stuck(blocked);
    assert(!stuck.boot());
    assert(blocked.trace.find('C') == std::string::npos);
    assert(blocked.trace.find('S') == std::string::npos);
    blocked.stuck = false;
    assert(stuck.cleanup());
    assert(blocked.trace.substr(blocked.trace.size() - 4) == "LICS");
}
