#pragma once
#include <cstdint>
#include <cstddef>
using UInt8 = uint8_t;
using UInt16 = uint16_t;
using UInt32 = uint32_t;
inline void IOSleep(unsigned) {}
