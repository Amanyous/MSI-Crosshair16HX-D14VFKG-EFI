#include "../src/StreamRestore.hpp"
#include <cassert>

struct RestoreBackend {
    unsigned writes = 0, failAt = 0;
    bool stopped = true;
    bool write() { return ++writes != failAt; }
    bool update32(uint32_t, uint32_t, uint32_t) { return write(); }
    bool write32(uint32_t, uint32_t) { return write(); }
    bool write16(uint32_t, uint16_t) { return write(); }
    bool write8(uint32_t, uint8_t) { return write(); }
    bool waitStopped(uint32_t, unsigned timeout) { assert(timeout == 5); return stopped; }
};

int main()
{
    using namespace OhMyDSPPlatform;
    StreamSnapshot saved {};
    RestoreBackend ok;
    assert(restoreStream(2, 0x804, saved, ok) && ok.writes == 10);
    RestoreBackend stuck;
    stuck.stopped = false;
    assert(!restoreStream(2, 0x804, saved, stuck) && stuck.writes == 1);
    for (unsigned i = 1; i <= 10; ++i) {
        RestoreBackend failed;
        failed.failAt = i;
        assert(!restoreStream(2, 0x804, saved, failed));
        assert(failed.writes == i);
    }
    RestoreBackend invalid;
    saved.control = 2;
    assert(!restoreStream(2, 0x804, saved, invalid) && invalid.writes == 0);
    saved.control = 0;
    assert(!restoreStream(30, 0x804, saved, invalid) && invalid.writes == 0);
}
