#include "../src/IccmaxSession.hpp"
#include <cassert>

struct Hardware {
    unsigned writes = 0, failAt = 0;
    bool stopped = true, snapshotOk = true, lostBeforeWrite = false;
    unsigned checks = 0;
    bool streamStillUnused(unsigned) { return !(lostBeforeWrite && ++checks >= 2); }
    bool snapshotStream(unsigned, uint32_t, OhMyDSPPlatform::StreamSnapshot &s)
    { s = {}; return snapshotOk; }
    bool readGuardband(uint8_t &v) { v = 17; return true; }
    bool write() { return ++writes != failAt; }
    bool write32(uint32_t, uint32_t) { return write(); }
    bool write16(uint32_t, uint16_t) { return write(); }
    bool write8(uint32_t, uint8_t) { return write(); }
    bool update32(uint32_t, uint32_t, uint32_t) { return write(); }
    bool update8(uint32_t, uint32_t, uint32_t) { return write(); }
    bool waitStopped(uint32_t, unsigned) { return stopped; }
};
int main()
{
    using OhMyDSPPlatform::IccmaxSession;
    for (unsigned failure = 1; failure <= 9; ++failure) {
        Hardware hw;
        hw.failAt = failure;
        IccmaxSession<Hardware> s(hw, 2, 4, 0x804, 0x4000);
        assert(!s.start(0x1000, 2));
        assert(s.mayReleaseDma());
        const auto before = hw.writes;
        assert(s.cleanup() && hw.writes == before);
    }
    Hardware hw;
    IccmaxSession<Hardware> s(hw, 2, 4, 0x804, 0x4000);
    assert(s.start(0x1000, 2) && s.active() && !s.mayReleaseDma());
    hw.stopped = false;
    assert(!s.cleanup() && !s.mayReleaseDma());
    hw.stopped = true;
    assert(s.cleanup() && !s.active() && s.mayReleaseDma());
    assert(!s.start(0x1000, 2));
    Hardware bad;
    bad.snapshotOk = false;
    IccmaxSession<Hardware> rejected(bad, 2, 4, 0x804, 0x4000);
    assert(!rejected.start(0x1000, 2) && bad.writes == 0);
    Hardware race;
    race.lostBeforeWrite = true;
    IccmaxSession<Hardware> lost(race, 2, 4, 0x804, 0x4000);
    assert(!lost.start(0x1000, 2) && race.writes == 0 && lost.mayReleaseDma());
    assert(lost.cleanup() && race.writes == 0);
}
