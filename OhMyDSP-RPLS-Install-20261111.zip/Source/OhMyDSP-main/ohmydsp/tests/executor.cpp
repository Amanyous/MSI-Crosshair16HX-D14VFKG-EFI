#include "../src/RegisterExecutor.hpp"
#include <cassert>
#include <vector>

struct Registers {
    unsigned calls = 0, failAt = 0;
    bool available = true;
    std::vector<OhMyDSPPlatform::RegisterStep> writes;
    bool streamStillUnused(unsigned) { return available; }
    bool apply(OhMyDSPPlatform::RegisterOperation op, uint32_t off,
               uint32_t mask, uint32_t value)
    {
        if (++calls == failAt) return false;
        writes.push_back({op, off, mask, value});
        return true;
    }
    bool write32(uint32_t o, uint32_t v)
    { return apply(OhMyDSPPlatform::RegisterOperation::Write32, o, 0xffffffff, v); }
    bool update32(uint32_t o, uint32_t m, uint32_t v)
    { return apply(OhMyDSPPlatform::RegisterOperation::Update32, o, m, v); }
    bool update8(uint32_t o, uint32_t m, uint32_t v)
    { return apply(OhMyDSPPlatform::RegisterOperation::Update8, o, m, v); }
};

int main()
{
    using namespace OhMyDSPPlatform;
    const auto plan = planIccmax(2, 4, 0x804, 0x1000, 2);
    auto run = [](const IccmaxPlan &p, Registers &r, uint32_t size = 0x4000) {
        return executeIccmax(p, 2, 4, 0x804, 0x1000, 2, size, r);
    };
    Registers success;
    assert(run(plan, success) && success.writes.size() == 9);
    for (unsigned failure = 1; failure <= 9; ++failure) {
        Registers r;
        r.failAt = failure;
        assert(!run(plan, r));
        assert(r.calls == failure && r.writes.size() == failure - 1);
    }
    Registers busy;
    busy.available = false;
    assert(!run(plan, busy) && busy.calls == 0);
    for (unsigned i = 0; i < 9; ++i) {
        auto corrupted = plan;
        corrupted.steps[i].offset = 8; // Global controller reset is forbidden.
        Registers r;
        assert(!run(corrupted, r) && r.calls == 0);
    }
    Registers shortBar;
    assert(!run(plan, shortBar, 0x1048) && shortBar.calls == 0);
}
