#include "../src/Platform.hpp"
#include <cassert>
using namespace OhMyDSPPlatform;
static_assert(identify(0x8086, 0x7a50) == Kind::RaptorLakeS);
static_assert(!permitsLegacyStartup(identify(0x8086, 0x7a50)));
static_assert(!permitsRplsStartup());
static_assert(permitsLegacyStartup(identify(0x8086, 0x06c8)));
static_assert(!permitsLegacyStartup(identify(0x1234, 0x06c8)));
static_assert(!permitsLegacyStartup(identify(0x8086, 0xffff)));
static_assert(raptorLakeS().presentCoreMask == 3);
static_assert(raptorLakeS().initCoreMask == 1);
static_assert(raptorLakeS().hostManagedCoreMask == 1);
static_assert(raptorLakeS().requiresIccmax);
static_assert(!unused({2, 0, 0, 0}));
static_assert(!unused({0, 0, 4096, 0}));
static_assert(unused({0x40000, 0, 0, 0}));
static_assert(streamTag(6, 7, 9) == 7);
static_assert(streamTag(15, 7, 9) == 9);
static_assert(streamTag(7, 7, 9) == 1);
static_assert(streamTag(16, 7, 9) == 0);
int main()
{
    StreamState streams[8] {};
    streams[0].control = 2;
    streams[7].cbl = 4096;
    auto plan = planStreams(4, 4, streams, 8);
    assert(plan.valid());
    assert(plan.capture == 3 && plan.iccmax == 2 && plan.loader == 6);
    streams[2].bdlHigh = 1;
    plan = planStreams(4, 4, streams, 8);
    assert(plan.iccmax == 1);
    streams[1].control = 2;
    assert(!planStreams(4, 4, streams, 8).valid());
    assert(!planStreams(4, 4, streams, 7).valid());
    assert(!planStreams(4, 4, nullptr, 8).valid());
    assert(!planStreams(1, 4, streams, 8).valid());
    // Observed 2026-11-11: AppleHDA has configured SD0/SD7, all other
    // descriptors carry only the direction bit. An idle RUN bit is not ownership.
    StreamState live[16] {};
    for (auto &stream : live) stream.control = 0x40000;
    live[0] = {0x140000, 0x30000, 0x2e2ca000, 0};
    live[7] = {0x140000, 0x60000, 0x2e2c9000, 0};
    auto livePlan = planStreams(7, 9, live, 16);
    assert(livePlan.valid());
    assert(livePlan.capture == 6 && livePlan.iccmax == 5 && livePlan.loader == 15);
    live[6].control |= 2;
    livePlan = planStreams(7, 9, live, 16);
    assert(livePlan.capture == 5 && livePlan.iccmax == 4);
    return 0;
}
