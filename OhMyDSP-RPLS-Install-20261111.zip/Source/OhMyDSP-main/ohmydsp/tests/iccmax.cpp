#include "../src/IccmaxPlan.hpp"
#include <cassert>

int main()
{
    using namespace OhMyDSPPlatform;
    auto plan = planIccmax(2, 4, 0x804, 0x123456780ULL, 2);
    assert(plan.valid);
    assert(plan.steps[2].value == 0x23456780);
    assert(plan.steps[3].value == 1);
    assert(plan.steps[4].offset == 0xc8 && plan.steps[4].value == 4096);
    assert(plan.steps[5].mask == 0xffff && plan.steps[5].value == 1);
    assert(plan.steps[6].mask == 4 && plan.steps[6].value == 4);
    assert(plan.steps[7].operation == RegisterOperation::Update8);
    assert(plan.steps[7].mask == 0x3f && plan.steps[7].value == (95 & 0x3f));
    assert(plan.steps[8].mask == 2); // No interrupt-enable bits.
    assert(!planIccmax(4, 4, 0x804, 0x1000, 2).valid);
    assert(!planIccmax(2, 4, 0x805, 0x1000, 2).valid);
    assert(!planIccmax(2, 4, 0x804, 0x1001, 2).valid);
    assert(!planIccmax(2, 4, 0x804, 0, 2).valid);
    assert(!planIccmax(2, 4, 0x804, 0x1000, 257).valid);
    assert(!planIccmax(2, 4, 0x804, 0x1000, 0).valid);
}
