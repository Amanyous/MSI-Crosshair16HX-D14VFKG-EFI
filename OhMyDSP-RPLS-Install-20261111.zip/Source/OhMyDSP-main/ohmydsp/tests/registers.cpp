#include "../src/HdaRegisters.hpp"
#include "../src/IccmaxSession.hpp"
#include <cassert>
#include <cstring>
#include <iostream>

int main()
{
    using namespace OhMyDSPPlatform;
    alignas(16) uint8_t bar[0x4000] {};
    HdaRegisters hw(bar, sizeof(bar));
    constexpr unsigned base = 0xc0; // SD2
    assert(hw.write32(base, 0xa5040000)); // SDSTS must survive SDCTL updates.
    assert(hw.update32(base, 2, 2));
    assert(bar[base + 3] == 0xa5 && bar[base + 2] == 4 && bar[base] == 2);
    assert(hw.update32(base, 2, 0) && bar[base + 3] == 0xa5);
    assert(!hw.update32(base, 0xff000000, 0));
    assert(!hw.update32(base, 2, 4));
    assert(!hw.write32(0x4000, 0) && !hw.write16(0x3fff, 0));
    assert(!hw.write32(1, 0) && !hw.write8(0x4000, 0));
    assert(!hw.streamStillUnused(30));
    assert(hw.write32(base, 0x40000));
    assert(hw.write32(0x804, 1u << 7));
    assert(hw.write8(0x1048, 0xd1));
    IccmaxSession<HdaRegisters> s(hw, 2, 4, 0x804, sizeof(bar));
    assert(s.start(0x1000, 2));
    assert(bar[base] == 2 && bar[0x1048] == 0xdf);
    assert(!s.mayReleaseDma());
    assert(s.cleanup() && s.mayReleaseDma());
    assert(bar[0x1048] == 0xd1 && bar[base] == 0 && bar[base + 2] == 4);
    assert(*reinterpret_cast<uint32_t *>(bar + 0x804) == (1u << 7));
    assert(*reinterpret_cast<uint32_t *>(bar + base + 0x18) == 0);
    // Simulated RAM does not implement the hardware's W1C status byte.
    assert(hw.write32(base, 0x40000));
    assert(hw.write16(base + 0x0c, 7) && hw.write16(base + 0x12, 0x31));
    StreamSnapshot capture {};
    assert(hw.snapshotStream(2, 0x804, capture));
    assert(hw.write32(base + 8, 4096));
    assert(hw.write32(base + 0x18, 0x1000));
    assert(hw.write16(base + 0x0c, 1) && hw.write16(base + 0x12, 0x41));
    assert(hw.update32(0x804, 1u << 2, 1u << 2));
    assert(hw.update32(base, 0xf00002, 0x200002));
    assert(restoreStream(2, 0x804, capture, hw));
    assert(hw.streamStillUnused(2));
    assert(*reinterpret_cast<uint16_t *>(bar + base + 0x0c) == 7);
    assert(*reinterpret_cast<uint16_t *>(bar + base + 0x12) == 0x31);
    assert(*reinterpret_cast<uint32_t *>(bar + 0x804) == (1u << 7));
    HdaRegisters shortBar(bar, 0x81);
    StreamSnapshot saved {};
    assert(!shortBar.snapshotStream(0, 0x804, saved));
    HdaRegisters missing(nullptr, 0x4000);
    assert(!missing.write32(0, 1) && !missing.streamStillUnused(0));
    std::cout << "PASS: actual register adapter on bounded simulated BAR; not hardware validation\n";
}
