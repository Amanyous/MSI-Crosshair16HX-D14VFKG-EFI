#pragma once
#include <stdint.h>
#include <stddef.h>

namespace OhMyDSPPlatform {
struct FirmwareManifest {
    uint32_t payloadOffset = 0, payloadBytes = 0;
    uint32_t downbox = 0, downSize = 0, upbox = 0, upSize = 0;
};

inline uint32_t little32(const uint8_t *p)
{
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) |
           (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}

inline bool parseFirmware(const uint8_t *data, size_t bytes,
                          uint32_t expectedBytes, size_t barBytes,
                          FirmwareManifest &result)
{
    result = {};
    if (!data || bytes != expectedBytes || bytes < 20 ||
        little32(data) != 0x6e614d58) return false;
    const uint32_t full = little32(data + 4), header = little32(data + 8);
    if (full < 16 || full > bytes - 4 || header < 16 || header > full ||
        (header & 3) || (full & 3) ||
        little32(data + full) != 0x44504324) return false;
    FirmwareManifest parsed;
    parsed.payloadOffset = full;
    parsed.payloadBytes = static_cast<uint32_t>(bytes - full);
    for (uint32_t pos = header; pos < full;) {
        if (full - pos < 8) return false;
        const uint32_t type = little32(data + pos);
        const uint32_t size = little32(data + pos + 4);
        if (size < 8 || size > full - pos || (size & 3)) return false;
        if (type == 1) {
            if (size < 24) return false;
            const uint32_t count = little32(data + pos + 20);
            if (count > (size - 24) / 24) return false;
            for (uint32_t i = 0; i < count; ++i) {
                const uint8_t *w = data + pos + 24 + 24 * i;
                const uint32_t kind = little32(w + 4);
                const uint32_t id = little32(w + 8);
                const uint32_t length = little32(w + 16);
                const uint32_t offset = little32(w + 20);
                const uint64_t address = 0x80000ULL + uint64_t(id) * 0x20000 + offset;
                if (length == 0 || address > barBytes ||
                    length > barBytes - address || (address & 3)) return false;
                if (kind == 0) {
                    if (parsed.downSize) return false;
                    parsed.downbox = static_cast<uint32_t>(address);
                    parsed.downSize = length;
                } else if (kind == 1) {
                    if (parsed.upSize) return false;
                    parsed.upbox = static_cast<uint32_t>(address);
                    parsed.upSize = length;
                }
            }
        }
        pos += size;
    }
    if (parsed.downSize < 384 || parsed.upSize < 108 ||
        (uint64_t(parsed.downbox) < uint64_t(parsed.upbox) + parsed.upSize &&
         uint64_t(parsed.upbox) < uint64_t(parsed.downbox) + parsed.downSize))
        return false;
    result = parsed;
    return true;
}
}
