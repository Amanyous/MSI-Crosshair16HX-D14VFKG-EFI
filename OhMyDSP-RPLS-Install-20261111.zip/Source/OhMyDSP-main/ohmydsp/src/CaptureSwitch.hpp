#pragma once
#include <stdint.h>
#include <stddef.h>
#include "FirmwareManifest.hpp"

namespace OhMyDSPPlatform {
inline bool buildRplsCaptureSwitch(const uint8_t *blob, size_t bytes,
                                   uint32_t (&control)[27])
{
    if (!blob || bytes < 8 || little32(blob) != 0x43504944 ||
        little32(blob + 4) != 19) return false;
    size_t pos = 8;
    unsigned matches = 0;
    for (unsigned i = 0; i < 19; ++i) {
        if (pos > bytes || bytes - pos < 8) return false;
        const uint32_t size = little32(blob + pos);
        if (little32(blob + pos + 4) != 0 || size < 12 || size > 384 ||
            (size & 3) || size > bytes - pos - 8) return false;
        const uint8_t *msg = blob + pos + 8;
        if (little32(msg) != size) return false;
        if (size == sizeof(control) && little32(msg + 4) == 0x50010000 &&
            little32(msg + 12) == 51 && little32(msg + 16) == 1 &&
            little32(msg + 20) == 2 && little32(msg + 24) == 1 &&
            little32(msg + 56) == 2) {
            for (unsigned word = 0; word < 27; ++word)
                control[word] = little32(msg + 4 * word);
            ++matches;
        }
        pos += size + 8;
    }
    if (pos != bytes || matches != 1) return false;
    control[23] = 0; control[24] = 1;
    control[25] = 1; control[26] = 1;
    return true;
}
}
