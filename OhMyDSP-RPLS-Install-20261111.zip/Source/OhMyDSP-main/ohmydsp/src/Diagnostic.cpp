// Manual diagnostic only: no firmware, DMA, power-up or audio implementation linked.
#include "OhMyDSP.hpp"
#include <kern/clock.h>
#ifdef OHMYDSP_FIRMWARE_EXPERIMENT
#include "DSPDevice.hpp"
#endif

#define super IOService
OSDefineMetaClassAndStructors(OhMyDSP, IOService)

void OhMyDSP::record(const char *fmt, ...)
{
    char line[300];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(line, sizeof(line), fmt, ap);
    va_end(ap);
    IOLog("OhMyDSP diagnostic: %s\n", line);
    if (!logBuf) logBuf = OSArray::withCapacity(64);
    if (!logBuf || logBuf->getCount() >= 1000) return;
    OSString *s = OSString::withCString(line);
    if (s) { logBuf->setObject(s); s->release(); }
}

void OhMyDSP::publishLog()
{
    if (!logBuf) return;
    OSArray *copy = OSArray::withArray(logBuf);
    if (copy) { setProperty("phase1-log", copy); copy->release(); }
}

static void diagnosticEntry(thread_call_param_t p, thread_call_param_t)
{
    static_cast<OhMyDSP *>(p)->runProbe();
}

bool OhMyDSP::start(IOService *provider)
{
    if (!super::start(provider)) return false;
    IOPCIDevice *pci = OSDynamicCast(IOPCIDevice, provider);
    if (!pci || pci->configRead16(0) != 0x8086 || pci->configRead16(2) != 0x7a50)
        return false;
#ifdef OHMYDSP_FIRMWARE_EXPERIMENT
    setProperty("DiagnosticReadOnly", false);
    setProperty("FirmwareExperiment", true);
#ifdef OHMYDSP_CAPTURE_EXPERIMENT
    setProperty("CaptureExperimentRevision", "rpl-capture-0.3.1");
#endif
#else
    setProperty("DiagnosticReadOnly", true);
#endif
    setProperty("DiagnosticComplete", false);
    tcall = thread_call_allocate(diagnosticEntry, this);
    if (!tcall) return false;
    pci->retain();
    pciDev = pci;
    uint64_t deadline;
    clock_interval_to_deadline(1, NSEC_PER_SEC, &deadline);
    thread_call_enter_delayed(tcall, deadline);
    registerService();
    return true;
}

static UInt32 read32(volatile UInt8 *base, size_t offset)
{
    return *reinterpret_cast<volatile UInt32 *>(base + offset);
}

#ifdef OHMYDSP_FIRMWARE_EXPERIMENT
void OhMyDSP::dspLog(void *ctx, const char *fmt, ...)
{
    char line[300];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(line, sizeof(line), fmt, ap);
    va_end(ap);
    static_cast<OhMyDSP *>(ctx)->record("%s", line);
}
#endif

void OhMyDSP::runProbe()
{
    IOPCIDevice *pci = pciDev;
    if (!pci) return;
    UInt16 command = pci->configRead16(4);
    UInt8 next = pci->configRead8(0x34), power = 0xff;
    for (unsigned i = 0; i < 48 && next >= 0x40 && next <= 0xf8 && !(next & 3); ++i) {
        UInt32 cap = pci->configRead32(next);
        if ((cap & 0xff) == 1) {
            power = pci->configRead16(next + 4) & 3;
            break;
        }
        next = (cap >> 8) & 0xff;
    }
    record("8086:7a50 command=%04x PM=D%u PGCTL=%08x CGCTL=%08x",
           command, power, pci->configRead32(0x44), pci->configRead32(0x48));
    if (!(command & 2) || power != 0) {
        record("BAR reads skipped: memory decode disabled or not D0");
    } else {
        IOMemoryMap *hda = pci->mapDeviceMemoryWithRegister(kIOPCIConfigBaseAddress0);
        IOMemoryMap *dspMap = pci->mapDeviceMemoryWithRegister(kIOPCIConfigBaseAddress4);
        if (hda) {
            size_t len = hda->getLength();
            volatile UInt8 *b = reinterpret_cast<volatile UInt8 *>(hda->getVirtualAddress());
            record("BAR0 phys=%llx len=%zx", (UInt64)hda->getPhysicalAddress(), len);
            if (b && len >= 0x80) {
                UInt16 gcap = *reinterpret_cast<volatile UInt16 *>(b);
                unsigned inputs = (gcap >> 8) & 15, outputs = (gcap >> 12) & 15;
                unsigned total = inputs + outputs + ((gcap >> 3) & 31);
                record("GCAP=%04x inputs=%u outputs=%u GCTL=%08x INTCTL=%08x INTSTS=%08x",
                       gcap, inputs, outputs, read32(b, 8), read32(b, 0x20), read32(b, 0x24));
                for (unsigned i = 0; i < total && i < 30; ++i) {
                    size_t offset = 0x80 + 0x20 * i;
                    if (offset + 0x20 > len) break;
                    record("SD%u CTLSTS=%08x LPIB=%08x CBL=%08x FMT=%08x BDL=%08x:%08x",
                           i, read32(b, offset), read32(b, offset + 4),
                           read32(b, offset + 8), read32(b, offset + 0x10),
                           read32(b, offset + 0x1c), read32(b, offset + 0x18));
                }
                UInt32 offset = read32(b, 0x14) & 0xffff;
                for (unsigned i = 0; i < 16 && offset >= 0x40 &&
                     !(offset & 3) && offset <= len && len - offset >= 12; ++i) {
                    UInt32 cap = read32(b, offset);
                    record("cap@%04x header=%08x +4=%08x +8=%08x",
                           offset, cap, read32(b, offset + 4), read32(b, offset + 8));
                    if (cap == 0xffffffff) break;
                    offset = cap & 0xffff;
                }
                if (len >= 0x104c)
                    record("EM2=%08x LTRP=%08x", read32(b, 0x1030), read32(b, 0x1048));
            }
#ifndef OHMYDSP_FIRMWARE_EXPERIMENT
            hda->release();
#endif
        } else record("BAR0 mapping failed");
        if (dspMap) {
            size_t len = dspMap->getLength();
            volatile UInt8 *b = reinterpret_cast<volatile UInt8 *>(dspMap->getVirtualAddress());
            record("BAR4 phys=%llx len=%zx", (UInt64)dspMap->getPhysicalAddress(), len);
            if (b && len >= 0xec) {
                record("ADSPCS=%08x ADSPIC=%08x ADSPIS=%08x",
                       read32(b, 4), read32(b, 8), read32(b, 12));
                record("HIPCTDR=%08x HIPCTDA=%08x HIPCTDD=%08x HIPCIDR=%08x HIPCIDA=%08x HIPCIDD=%08x HIPCCTL=%08x",
                       read32(b, 0xc0), read32(b, 0xc4), read32(b, 0xc8),
                       read32(b, 0xd0), read32(b, 0xd4), read32(b, 0xd8), read32(b, 0xe8));
            }
            record("SRAM intentionally not read");
#ifndef OHMYDSP_FIRMWARE_EXPERIMENT
            dspMap->release();
#endif
        } else record("BAR4 mapping failed");
#ifdef OHMYDSP_FIRMWARE_EXPERIMENT
        if (hda && dspMap && hda->getLength() >= 0x104c &&
            dspMap->getLength() >= 0x100000) {
            auto b0 = reinterpret_cast<volatile UInt8 *>(hda->getVirtualAddress());
            auto b4 = reinterpret_cast<volatile UInt8 *>(dspMap->getVirtualAddress());
            bool idle = b0 && b4;
            const UInt16 gcap = idle ? *reinterpret_cast<volatile UInt16 *>(b0) : 0;
            const unsigned streams = ((gcap >> 8) & 15) + ((gcap >> 12) & 15);
            if (!streams || streams > 30) idle = false;
            for (unsigned i = 0; idle && i < streams; ++i)
                if (read32(b0, 0x80 + 0x20 * i) & 2) idle = false;
            if (idle) {
                DSPDevice *device = new DSPDevice(pci, b0, hda->getLength(),
                    b4, dspMap->getLength(), false, dspLog, this);
                if (device) {
                    bool ready = device->checkIdle() && device->loadFirmware() &&
                                 device->experimentalFirmwareBoot();
                    record("Firmware experiment FW_READY=%u", ready);
#ifdef OHMYDSP_CAPTURE_EXPERIMENT
                    bool captured = ready && device->loadPipelineBlob() &&
                                    device->sendPipeline(19) &&
                                    device->startStream(4, device->captureStreamIndex(6), 0);
                    UInt32 position = 0, status = 0;
                    if (captured) {
                        IOSleep(1000);
                        device->sample(&position, &status);
                    }
                    DSPDevice::StopInfo stopped;
                    const bool dmaStopped = device->stopDma(&stopped);
                    record("Capture experiment started=%u position=%u status=%x stopped=%u",
                           captured, position, status, dmaStopped);
                    if (captured && dmaStopped && stopped.stopped &&
                        position > 0 && position < device->captureBytes()) {
                        const UInt32 bytes = position & ~7u;
                        const SInt32 *pcm = static_cast<const SInt32 *>(device->captureBuffer());
                        UInt32 nonzero = 0;
                        UInt64 peak = 0;
                        for (UInt32 i = 0; pcm && i < bytes / 4; ++i) {
                            const SInt64 sample = pcm[i];
                            const UInt64 magnitude = sample < 0 ? -sample : sample;
                            if (sample) ++nonzero;
                            if (magnitude > peak) peak = magnitude;
                        }
                        record("Capture PCM bytes=%u nonzero=%u peak=%llu", bytes, nonzero, peak);
                        if (pcm) {
                            OSData *data = OSData::withBytes(pcm, bytes);
                            if (data) { setProperty("CapturePCM", data); data->release(); }
                        }
                        setProperty("CaptureNonzeroSamples", nonzero, 32);
                    }
                    device->freeStream();
#endif
                    device->teardown(false);
                    const bool clean = device->safeToRestart() && read32(b4, 4) == 0x303;
                    record("Firmware experiment cleanup=%u ADSPCS=%08x", clean, read32(b4, 4));
                    setProperty("FirmwareReadyObserved", ready);
                    setProperty("FirmwareCleanupComplete", clean);
                    delete device;
                }
            } else record("Firmware experiment refused: HDA stream running or invalid GCAP");
        }
        if (hda) hda->release();
        if (dspMap) dspMap->release();
#endif
    }
    record("read-only probe complete");
    publishLog();
    setProperty("DiagnosticComplete", true);
}

void OhMyDSP::stop(IOService *provider)
{
    if (tcall) {
        thread_call_cancel(tcall);
        while (!thread_call_free(tcall)) IOSleep(10);
        tcall = nullptr;
    }
    if (pciDev) { pciDev->release(); pciDev = nullptr; }
    if (logBuf) { logBuf->release(); logBuf = nullptr; }
    super::stop(provider);
}
