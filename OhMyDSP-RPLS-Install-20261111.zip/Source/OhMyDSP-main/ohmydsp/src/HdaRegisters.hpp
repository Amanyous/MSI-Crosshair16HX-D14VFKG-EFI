#pragma once
#include <IOKit/IOLib.h>
#include "Platform.hpp"
#include "StreamRestore.hpp"

namespace OhMyDSPPlatform {
// Explicitly constructed by a future authorized loader; never maps a BAR or
// changes PCI power state itself. Caller must serialize access and own streams.
class HdaRegisters {
public:
    typedef void (*LogFn)(void *, const char *, ...);
    HdaRegisters(volatile UInt8 *address, size_t length,
                 LogFn logger = nullptr, void *context = nullptr)
        : base(address), bytes(length), log(logger), logContext(context) {}

    bool snapshotStream(unsigned index, UInt32 ppctl, StreamSnapshot &saved)
    {
        if (!streamStillUnused(index) || (ppctl & 3) || !contains(ppctl, 4))
            return false;
        const UInt32 off = 0x80 + 0x20 * index;
        const UInt32 pp = read32(ppctl);
        if (pp == 0xffffffff || (pp & (1u << index))) return false;
        saved = {read32(off) & 0x00ffffff, read32(off + 8),
                 read32(off + 0x18), read32(off + 0x1c),
                 *reinterpret_cast<volatile UInt16 *>(base + off + 0x0c),
                 *reinterpret_cast<volatile UInt16 *>(base + off + 0x12),
                 (pp & (1u << index)) != 0};
        return true;
    }
    bool readGuardband(uint8_t &value)
    {
        if (!contains(0x1048, 1)) return false;
        value = base[0x1048] & 0x3f;
        return true;
    }
    bool streamStillUnused(unsigned index)
    {
        if (index >= 30) return false;
        const unsigned off = 0x80 + 0x20 * index;
        if (!contains(off, 0x20)) return false;
        const auto control = read32(off);
        if (control == 0xffffffff) return false;
        return unused({control & 0x00ffffff, read32(off + 8), read32(off + 0x18),
                       read32(off + 0x1c)});
    }

    bool write32(UInt32 off, UInt32 value)
    {
        if ((off & 3) || !contains(off, 4)) return false;
        if (log) log(logContext, "W32 BAR0+0x%x <- 0x%08x (RPL loader)", off, value);
        *reinterpret_cast<volatile UInt32 *>(base + off) = value;
        __atomic_thread_fence(__ATOMIC_SEQ_CST);
        return true;
    }
    bool write16(UInt32 off, UInt16 value)
    {
        if ((off & 1) || !contains(off, 2)) return false;
        if (log) log(logContext, "W16 BAR0+0x%x <- 0x%04x (RPL loader)", off, value);
        *reinterpret_cast<volatile UInt16 *>(base + off) = value;
        __atomic_thread_fence(__ATOMIC_SEQ_CST);
        return true;
    }
    bool write8(UInt32 off, UInt8 value)
    {
        if (!contains(off, 1)) return false;
        if (log) log(logContext, "W8 BAR0+0x%x <- 0x%02x (RPL loader)", off, value);
        base[off] = value;
        __atomic_thread_fence(__ATOMIC_SEQ_CST);
        return true;
    }
    bool update32(UInt32 off, UInt32 mask, UInt32 value)
    {
        if ((off & 3) || !contains(off, 4) || (value & ~mask)) return false;
        // SDCTL is 24 bits; its adjacent SDSTS byte is write-one-to-clear.
        if (off >= 0x80 && off < 0x440 && ((off - 0x80) % 0x20) == 0) {
            if (mask & 0xff000000) return false;
            const UInt32 old = static_cast<UInt32>(
                *reinterpret_cast<volatile UInt16 *>(base + off)) |
                (static_cast<UInt32>(base[off + 2]) << 16);
            const UInt32 next = (old & ~mask) | value;
            return write16(off, static_cast<UInt16>(next)) &&
                   write8(off + 2, static_cast<UInt8>(next >> 16));
        }
        const UInt32 old = read32(off);
        if (old == 0xffffffff) return false;
        return write32(off, (old & ~mask) | value);
    }
    bool update8(UInt32 off, UInt32 mask, UInt32 value)
    {
        if (!contains(off, 1) || mask > 0xff || (value & ~mask)) return false;
        const UInt8 old = base[off];
        return write8(off, static_cast<UInt8>((old & ~mask) | value));
    }
    bool waitStopped(UInt32 off, unsigned timeoutMs)
    {
        if ((off & 3) || !contains(off, 4) || timeoutMs > 100) return false;
        for (unsigned attempt = 0; attempt <= timeoutMs; ++attempt) {
            const UInt32 value = read32(off);
            if (value == 0xffffffff) return false;
            if (!(value & 2)) return true;
            if (attempt < timeoutMs) IOSleep(1);
        }
        return false;
    }

private:
    bool contains(size_t off, size_t width) const
    { return base && off <= bytes && width <= bytes - off; }
    UInt32 read32(UInt32 off) const
    { return *reinterpret_cast<volatile UInt32 *>(base + off); }
    volatile UInt8 *base;
    size_t bytes;
    LogFn log;
    void *logContext;
};
}
