#pragma once
#include "IccmaxPlan.hpp"

namespace OhMyDSPPlatform {
// Backend operations return false on failure. Validate the entire plan before
// any write; the caller owns rollback after a partial execution.
template <typename Backend>
bool executeIccmax(const IccmaxPlan &plan, unsigned stream, unsigned inputs,
                  uint32_t ppctl, uint64_t bdl, unsigned entries,
                  uint32_t barBytes, Backend &backend, bool *touched = nullptr)
{
    if (touched) *touched = false;
    const auto expected = planIccmax(stream, inputs, ppctl, bdl, entries);
    if (!plan.valid || !expected.valid) return false;
    for (unsigned i = 0; i < 9; ++i) {
        const auto &step = plan.steps[i];
        const auto &reference = expected.steps[i];
        const unsigned width = step.operation == RegisterOperation::Update8 ? 1 : 4;
        if (step.operation != reference.operation || step.offset != reference.offset ||
            step.mask != reference.mask || step.value != reference.value ||
            step.offset > barBytes || width > barBytes - step.offset)
            return false;
    }
    // Recheck ownership after validation, immediately before the first write.
    if (!backend.streamStillUnused(stream)) return false;
    if (touched) *touched = true;
    for (const auto &step : plan.steps) {
        bool ok = false;
        switch (step.operation) {
        case RegisterOperation::Write32:
            ok = backend.write32(step.offset, step.value);
            break;
        case RegisterOperation::Update32:
            ok = backend.update32(step.offset, step.mask, step.value);
            break;
        case RegisterOperation::Update8:
            ok = backend.update8(step.offset, step.mask, step.value);
            break;
        }
        if (!ok) return false;
    }
    return true;
}
}
