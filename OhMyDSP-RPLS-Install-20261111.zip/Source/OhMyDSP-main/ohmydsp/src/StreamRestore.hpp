#pragma once
#include <stdint.h>

namespace OhMyDSPPlatform {
struct StreamSnapshot {
    uint32_t control, cbl, bdlLow, bdlHigh;
    uint16_t lvi, format;
    bool decoupled;
};

// The backend supplies bounded polling. Leave DMA mappings alive on any error.
// Do not rewrite a descriptor until its RUN bit is confirmed clear.
template <typename Backend>
bool restoreStream(unsigned index, uint32_t ppctl,
                   const StreamSnapshot &saved, Backend &hw)
{
    if (index >= 30 || (saved.control & 2) ||
        ppctl < 0x100 || ppctl > 0x3ffc || (ppctl & 3))
        return false;
    const uint32_t base = 0x80 + 0x20 * index;
    if (!hw.update32(base, 2, 0) || !hw.waitStopped(base, 5))
        return false;
    if (!hw.write32(base + 0x18, saved.bdlLow) ||
        !hw.write32(base + 0x1c, saved.bdlHigh) ||
        !hw.write32(base + 8, saved.cbl) ||
        !hw.write16(base + 0x0c, saved.lvi) ||
        !hw.write16(base + 0x12, saved.format) ||
        !hw.write8(base + 3, 0x1c) ||
        !hw.write16(base, static_cast<uint16_t>(saved.control)) ||
        !hw.write8(base + 2, static_cast<uint8_t>(saved.control >> 16)))
        return false;
    const uint32_t bit = 1u << index;
    return hw.update32(ppctl, bit, saved.decoupled ? bit : 0);
}
}
