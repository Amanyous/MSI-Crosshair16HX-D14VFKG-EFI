// Explicit instantiation checks kernel/backend compatibility without creating
// a session or connecting it to the driver's startup path.
#include "HdaRegisters.hpp"
#include "IccmaxSession.hpp"
template class OhMyDSPPlatform::IccmaxSession<OhMyDSPPlatform::HdaRegisters>;
