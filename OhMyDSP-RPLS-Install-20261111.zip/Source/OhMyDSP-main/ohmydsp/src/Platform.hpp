#pragma once

namespace OhMyDSPPlatform {
enum class Kind { Unsupported, CometLakeH, RaptorLakeS };

constexpr Kind identify(unsigned vendor, unsigned device)
{
    return vendor != 0x8086 ? Kind::Unsupported :
           device == 0x06c8 ? Kind::CometLakeH :
           device == 0x7a50 ? Kind::RaptorLakeS : Kind::Unsupported;
}

constexpr bool permitsLegacyStartup(Kind kind)
{
    return kind == Kind::CometLakeH;
}

constexpr bool permitsRplsStartup() {
#ifdef OHMYDSP_RPL_LIVE_TEST
    return true; // Explicit manual test only; default EFI builds remain blocked.
#else
    return false;
#endif
}

constexpr bool permitsProbe(Kind kind)
{
    return permitsLegacyStartup(kind) ||
           (kind == Kind::RaptorLakeS && permitsRplsStartup());
}

struct LoaderProfile {
    unsigned presentCoreMask;
    unsigned initCoreMask;
    unsigned hostManagedCoreMask;
    unsigned firmwareBytes;
    bool requiresIccmax;
};

constexpr LoaderProfile raptorLakeS()
{
    return {0x3, 0x1, 0x1, 447232, true};
}

// Input descriptors precede output descriptors. Never borrow an active or
// already configured stream; callers must revalidate immediately before use.
struct StreamState {
    unsigned control;
    unsigned cbl;
    unsigned bdlLow;
    unsigned bdlHigh;
};

constexpr bool unused(const StreamState &stream)
{
    // Bit 18 is the direction bit, not evidence of stream ownership.
    return (stream.control & ~0x00040000u) == 0 &&
           stream.cbl == 0 && stream.bdlLow == 0 && stream.bdlHigh == 0;
}

struct LoaderStreams {
    int capture;
    int iccmax;
    int loader;
    constexpr bool valid() const
    {
        return capture >= 0 && iccmax >= 0 && loader >= 0 &&
               capture != iccmax;
    }
};

constexpr unsigned streamTag(unsigned index, unsigned inputs, unsigned outputs)
{
    return inputs <= 15 && outputs <= 15 && index < inputs + outputs ?
           (index < inputs ? index + 1 : index - inputs + 1) : 0;
}

inline LoaderStreams planStreams(unsigned inputs, unsigned outputs,
                                 const StreamState *streams, unsigned count)
{
    LoaderStreams result {-1, -1, -1};
    if (!streams || inputs < 2 || outputs == 0 ||
        inputs > 15 || outputs > 15 || inputs + outputs > count)
        return result;
    for (unsigned i = inputs; i > 0; --i) {
        if (!unused(streams[i - 1])) continue;
        if (result.capture < 0) result.capture = static_cast<int>(i - 1);
        else { result.iccmax = static_cast<int>(i - 1); break; }
    }
    for (unsigned i = inputs + outputs; i > inputs; --i) {
        if (unused(streams[i - 1])) {
            result.loader = static_cast<int>(i - 1);
            break;
        }
    }
    return result;
}
}
