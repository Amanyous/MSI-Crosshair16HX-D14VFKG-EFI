#include "DSPDevice.hpp"
#include <IOKit/IOLib.h>

#define RLOG(...) do { if (logFn) logFn(logCtx, __VA_ARGS__); } while (0)

static UInt32 read32(volatile UInt8 *base, UInt32 offset)
{ return *reinterpret_cast<volatile UInt32 *>(base + offset); }

bool DSPDevice::checkRplsIdle()
{
    if (dry || !b0 || !b4 || len0 < 0x104c || len4 < 0x100000 ||
        (pci->configRead16(4) & 6) != 6 || !(read32(b0, 8) & 1)) return false;
    const UInt32 cores = read32(b4, 4);
    // Both present cores must be reset, stalled and powered off.
    if (cores == 0xffffffff || (cores & 0x03030303) != 0x00000303) {
        RLOG("RPL precheck refused: ADSPCS=0x%08x", cores);
        return false;
    }
    ppBase = spibBase = 0;
    UInt32 off = read32(b0, 0x14) & 0xffff;
    for (unsigned i = 0; i < 16 && off; ++i) {
        if (off < 0x100 || (off & 3) || off > len0 || len0 - off < 8) return false;
        const UInt32 cap = read32(b0, off);
        if (cap == 0xffffffff) return false;
        const UInt32 id = (cap >> 16) & 0xfff;
        if (id == 3) ppBase = off;
        if (id == 4) spibBase = off;
        off = cap & 0xffff;
    }
    if (off || !ppBase || !spibBase) return false;
    const UInt16 gcap = *reinterpret_cast<volatile UInt16 *>(b0);
    inputCount = (gcap >> 8) & 15;
    const unsigned outputs = (gcap >> 12) & 15;
    const unsigned total = inputCount + outputs;
    if (inputCount < 2 || !outputs || total > 30 ||
        0x80 + 0x20 * total > len0 ||
        spibBase + 8 + 8 * total > len0) return false;
    OhMyDSPPlatform::StreamState states[30] {};
    const UInt32 pp = read32(b0, ppBase + 4), spib = read32(b0, spibBase + 4);
    if (pp == 0xffffffff || spib == 0xffffffff) return false;
    UInt32 tags = 1;
    for (unsigned i = 0; i < total; ++i) {
        const UInt32 s = 0x80 + 0x20 * i;
        states[i] = {read32(b0, s) & 0x00ffffff, read32(b0, s + 8),
                     read32(b0, s + 0x18), read32(b0, s + 0x1c)};
        tags |= 1u << ((states[i].control >> 20) & 15);
        if ((pp | spib) & (1u << i)) states[i].control |= 1;
    }
    rplStreams = OhMyDSPPlatform::planStreams(inputCount, outputs, states, total);
    if (!rplStreams.valid()) return false;
    loaderIndex = (UInt32)rplStreams.loader;
    loaderTag = OhMyDSPPlatform::streamTag(loaderIndex, inputCount, outputs);
    if (!loaderTag || (tags & (1u << loaderTag))) {
        RLOG("RPL loader refused: descriptor's fixed stream tag is already in use");
        return false;
    }
    sdOff = 0x80 + 0x20 * loaderIndex;
    RLOG("RPL precheck: inputs=%u outputs=%u capture=SD%d ICCMAX=SD%d loader=SD%d tag=%u",
         inputCount, outputs, rplStreams.capture, rplStreams.iccmax, rplStreams.loader, loaderTag);
    return true;
}

bool DSPDevice::allocIccmaxBuffers()
{
    if (iccBdlIova) return true;
    // A failed allocation is not retryable on the same owner.
    if (iccBuf || iccBdl || iccCmd || iccBdlCmd) return false;
    const UInt64 mask = 0x0000FFFFFFFFF000ULL;
    iccBuf = IOBufferMemoryDescriptor::inTaskWithPhysicalMask(kernel_task, kIODirectionInOut, 4096, mask);
    iccBdl = IOBufferMemoryDescriptor::inTaskWithPhysicalMask(kernel_task, kIODirectionInOut, 4096, mask);
    iccCmd = IODMACommand::withSpecification(kIODMACommandOutputHost64, 64, 0, IODMACommand::kMapped, 0, 1);
    iccBdlCmd = IODMACommand::withSpecification(kIODMACommandOutputHost64, 64, 0, IODMACommand::kMapped, 0, 1);
    if (!iccBuf || !iccBdl || !iccCmd || !iccBdlCmd ||
        iccCmd->setMemoryDescriptor(iccBuf) != kIOReturnSuccess ||
        iccBdlCmd->setMemoryDescriptor(iccBdl) != kIOReturnSuccess) return false;
    UInt64 offset = 0;
    UInt32 count = 1;
    IODMACommand::Segment64 data {}, bdl {};
    if (iccCmd->gen64IOVMSegments(&offset, &data, &count) != kIOReturnSuccess ||
        count != 1 || data.fLength < 4096 || !data.fIOVMAddr ||
        (data.fIOVMAddr & 127)) return false;
    offset = 0; count = 1;
    if (iccBdlCmd->gen64IOVMSegments(&offset, &bdl, &count) != kIOReturnSuccess ||
        count != 1 || bdl.fLength < 4096 || !bdl.fIOVMAddr ||
        (bdl.fIOVMAddr & 127)) return false;
    memset(iccBuf->getBytesNoCopy(), 0, 4096);
    memset(iccBdl->getBytesNoCopy(), 0, 4096);
    UInt32 *entries = static_cast<UInt32 *>(iccBdl->getBytesNoCopy());
    for (unsigned i = 0; i < 2; ++i) {
        const UInt64 address = data.fIOVMAddr + i * 2048;
        entries[4 * i] = (UInt32)address;
        entries[4 * i + 1] = (UInt32)(address >> 32);
        entries[4 * i + 2] = 2048;
    }
    __atomic_thread_fence(__ATOMIC_SEQ_CST);
    iccBdlIova = bdl.fIOVMAddr;
    return true;
}

bool DSPDevice::releaseLoader()
{
    if (!streamTouched) return true;
    if (!loaderSaved ||
        !OhMyDSPPlatform::restoreStream(loaderIndex, ppBase + 4, loaderSnapshot, registers)) {
        loaderStuck = true;
        return false;
    }
    const UInt32 bit = 1u << loaderIndex;
    if (!registers.write32(spibBase + 8 + 8 * loaderIndex, savedLoaderSpib) ||
        !registers.update32(spibBase + 4, bit, savedLoaderSpibEnabled ? bit : 0)) {
        loaderStuck = true;
        return false;
    }
    streamTouched = false;
    loaderSaved = false;
    return true;
}

bool DSPDevice::powerUpRpls()
{
    if (!fwFile || !bdlIova || nEnt < 2 || !checkIdle() || !allocIccmaxBuffers()) return false;
    const UInt32 bit = 1u << loaderIndex;
    if (!registers.snapshotStream(loaderIndex, ppBase + 4, loaderSnapshot)) return false;
    savedLoaderSpib = read32(b0, spibBase + 8 + 8 * loaderIndex);
    savedLoaderSpibEnabled = (read32(b0, spibBase + 4) & bit) != 0;
    loaderSaved = true;
    if (!iccmax.configure((unsigned)rplStreams.iccmax, inputCount, ppBase + 4) ||
        !iccmax.start(iccBdlIova, 2)) return false;
    // AppleHDA does not share our lock. Keep platform admission closed until
    // descriptor ownership is coordinated, even though this path compiles.
    if (!registers.streamStillUnused(loaderIndex) ||
        (read32(b0, ppBase + 4) & bit) ||
        (read32(b0, spibBase + 4) & bit)) return false;
    savedCG = pci->configRead32(0x48);
    savedPG = pci->configRead32(0x44);
    savedEM2 = read32(b0, 0x1030);
    if (savedCG == 0xffffffff || savedPG == 0xffffffff || savedEM2 == 0xffffffff) return false;
    gatingChanged = true;
    WC(0x48, savedCG & ~2u, "RPL CGCTL: disable DSP clock gating");
    W0(0x1030, savedEM2 & ~(1u << 13), "RPL EM2: disable L1");
    WC(0x44, savedPG | 4, "RPL PGCTL: disable DSP power gating");

    streamTouched = true;
    if (!registers.update32(ppBase + 4, bit, bit) ||
        !registers.update32(sdOff, 0x1e, 0) ||
        !registers.waitStopped(sdOff, 5) ||
        !registers.update32(sdOff, 1, 1) ||
        !poll(b0, sdOff, 1, 1, 5, "RPL loader reset") ||
        !registers.update32(sdOff, 1, 0) ||
        !poll(b0, sdOff, 1, 0, 5, "RPL loader leave reset") ||
        !registers.write8(sdOff + 3, 0x1c) ||
        !registers.update32(sdOff, 0xf00000, loaderTag << 20) ||
        !registers.write32(sdOff + 8, fwFile->getLength()) ||
        !registers.write16(sdOff + 0x12, 0x40) ||
        !registers.write16(sdOff + 0x0c, (UInt16)(nEnt - 1)) ||
        !registers.write32(sdOff + 0x18, (UInt32)bdlIova) ||
        !registers.write32(sdOff + 0x1c, (UInt32)(bdlIova >> 32)) ||
        !registers.write32(spibBase + 8 + 8 * loaderIndex, fwFile->getLength()) ||
        !registers.update32(spibBase + 4, bit, bit)) return false;

    dspPowered = true;
    U4(4, 1u << 16, 1u << 16, "RPL SPA core0 only");
    if (!poll(b4, 4, 1u << 24, 1u << 24, 50, "RPL CPA core0")) return false;
    for (unsigned i = 0; i < 3; ++i) {
        const UInt32 ssp = 0x10004 + i * 0x1000;
        savedSsp[i] = read32(b4, ssp);
        if (savedSsp[i] == 0xffffffff) return false;
        ++sspTouched;
        U4(ssp, 3u << 24, 3u << 24, "RPL SSP clock consumer");
    }
    W4(0xd0, 0x81004000 | ((loaderTag - 1) << 9), "RPL ROM_CONTROL purge+stream");
    U4(4, 1, 0, "RPL core0 leave reset");
    if (!poll(b4, 4, 1, 0, 50, "RPL CRST0 clear")) return false;
    U4(4, 1u << 8, 0, "RPL core0 unstall");
    if (!poll(b4, 4, 0x01000101, 0x01000000, 50, "RPL core0 running") ||
        !poll(b4, 0xd4, 0x80000000, 0x80000000, 500, "RPL ROM acknowledgement")) return false;
    W4(0xd4, 0x80000000, "RPL acknowledge ROM DONE");
    if (!poll(b4, 0x80000, 0xffffff, 1, 3000, "RPL ROM INIT_DONE")) return false;
    if (!registers.update32(sdOff, 2, 2)) return false;
    const bool entered = poll(b4, 0x80000, 0xffffff, 5, 3000, "RPL FW_ENTERED");
    if (!registers.update32(sdOff, 2, 0) || !registers.waitStopped(sdOff, 5)) {
        loaderStuck = true;
        return false;
    }
    if (!entered || !poll(b4, 0xc0, 0x80000000, 0x80000000, 2000, "RPL FW_READY")) return false;
    const UInt32 readyBytes = read32(b4, upbox), readyCommand = read32(b4, upbox + 4);
    const bool ready = readyBytes >= 108 && readyBytes <= upSize && readyCommand == 0x70000000;
    RLOG("RPL firmware reply: bytes=%u command=0x%x", readyBytes, readyCommand);
    W4(0xc0, 0x80000000, "RPL acknowledge FW_READY BUSY");
    W4(0xc4, 0x80000000, "RPL acknowledge FW_READY DONE");
    if (!ready || !releaseLoader() || !iccmax.cleanup()) return false;
    fwReady = true;
    return true;
}
