#pragma once
#include "RegisterExecutor.hpp"
#include "StreamRestore.hpp"

namespace OhMyDSPPlatform {
// The DMA owner must retain its buffers until cleanup() succeeds.
template <typename Registers>
class IccmaxSession {
public:
    IccmaxSession(Registers &registers, unsigned stream, unsigned inputs,
                  uint32_t ppctl, uint32_t barBytes)
        : hw(registers), index(stream), inputCount(inputs),
          pp(ppctl), length(barBytes) {}
    IccmaxSession(const IccmaxSession &) = delete;
    IccmaxSession &operator=(const IccmaxSession &) = delete;

    bool configure(unsigned stream, unsigned inputs, uint32_t ppctl)
    {
        if (touched) return false;
        index = stream; inputCount = inputs; pp = ppctl;
        attempted = false;
        return true;
    }

    bool start(uint64_t bdl, unsigned entries)
    {
        if (attempted) return false;
        attempted = true;
        const auto plan = planIccmax(index, inputCount, pp, bdl, entries);
        if (!plan.valid || length < 0x1049 || pp > length ||
            length - pp < 4 || !hw.streamStillUnused(index))
            return false;
        if (!hw.snapshotStream(index, pp, saved) ||
            !hw.readGuardband(guardband))
            return false;
        if (!executeIccmax(plan, index, inputCount, pp, bdl, entries, length, hw, &touched)) {
            cleanup();
            return false;
        }
        running = true;
        return true;
    }

    bool cleanup()
    {
        if (!touched) return true;
        if (!restoreStream(index, pp, saved, hw)) return false;
        running = false;
        if (!hw.update8(0x1048, 0x3f, guardband & 0x3f)) return false;
        touched = false;
        return true;
    }
    bool mayReleaseDma() const { return !touched; }
    bool active() const { return running; }

private:
    Registers &hw;
    unsigned index, inputCount;
    uint32_t pp, length;
    StreamSnapshot saved {};
    uint8_t guardband = 0;
    bool attempted = false, touched = false, running = false;
};
}
