#pragma once
#include <stdint.h>

namespace OhMyDSPPlatform {
enum class RegisterOperation { Write32, Update32, Update8 };
struct RegisterStep {
    RegisterOperation operation;
    uint32_t offset;
    uint32_t mask;
    uint32_t value;
};
struct IccmaxPlan {
    RegisterStep steps[9] {};
    bool valid = false;
};

// Offline register plan, not an MMIO executor. PPCTL is a BAR0 offset.
inline IccmaxPlan planIccmax(unsigned stream, unsigned inputCount,
                             uint32_t ppctl, uint64_t bdl, unsigned entries)
{
    IccmaxPlan plan;
    if (stream >= inputCount || inputCount > 15 ||
        ppctl < 0x100 || ppctl > 0x3ffc || (ppctl & 3) ||
        bdl == 0 || (bdl & 0x7f) || entries == 0 || entries > 256)
        return plan;
    const uint32_t base = 0x80 + 0x20 * stream;
    const uint32_t bit = 1u << stream;
    plan.steps[0] = {RegisterOperation::Write32, base + 0x18, 0xffffffff, 0};
    plan.steps[1] = {RegisterOperation::Write32, base + 0x1c, 0xffffffff, 0};
    plan.steps[2] = {RegisterOperation::Write32, base + 0x18, 0xffffffff,
                     static_cast<uint32_t>(bdl)};
    plan.steps[3] = {RegisterOperation::Write32, base + 0x1c, 0xffffffff,
                     static_cast<uint32_t>(bdl >> 32)};
    plan.steps[4] = {RegisterOperation::Write32, base + 0x08, 0xffffffff, 4096};
    plan.steps[5] = {RegisterOperation::Update32, base + 0x0c, 0xffff, entries - 1};
    plan.steps[6] = {RegisterOperation::Update32, ppctl, bit, bit};
    plan.steps[7] = {RegisterOperation::Update8, 0x1048, 0x3f, 95 & 0x3f};
    plan.steps[8] = {RegisterOperation::Update32, base, 2, 2};
    plan.valid = true;
    return plan;
}
}
