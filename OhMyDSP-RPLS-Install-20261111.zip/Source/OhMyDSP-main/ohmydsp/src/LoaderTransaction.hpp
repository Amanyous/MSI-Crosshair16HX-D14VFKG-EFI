#pragma once

namespace OhMyDSPPlatform {
// The backend must snapshot before writing and make each restore idempotent.
// A failed stop retains DMA storage: freeing it could corrupt kernel memory.
template <typename Backend>
class LoaderTransaction {
public:
    explicit LoaderTransaction(Backend &backend) : hw(backend) {}
    LoaderTransaction(const LoaderTransaction &) = delete;
    LoaderTransaction &operator=(const LoaderTransaction &) = delete;

    bool boot()
    {
        if (attempted) return false;
        attempted = true;
        if (!hw.preflight()) return false;
        if (!hw.snapshot()) return false;
        saved = true;
        // Mark ownership before invoking operations that may fail partway.
        iccmaxTouched = true;
        if (!hw.prepareIccmax()) return fail();
        loaderTouched = true;
        if (!hw.prepareLoader()) return fail();
        coreTouched = true;
        if (!hw.startCore0()) return fail();
        if (!hw.transferFirmware()) return fail();
        if (!hw.waitFirmwareReady()) return fail();
        if (!releaseStreams()) {
            cleanup();
            return false;
        }
        if (!hw.restoreGuardband()) return fail();
        ready = true;
        return true;
    }

    bool cleanup()
    {
        ready = false;
        // Do not power down or unmap storage beneath a running stream.
        if (!releaseStreams()) return false;
        if (coreTouched) {
            if (!hw.stopCore0()) return false;
            coreTouched = false;
        }
        if (saved) {
            if (!hw.restoreSnapshot()) return false;
            saved = false;
        }
        return true;
    }

    bool firmwareReady() const { return ready; }

private:
    bool fail() { cleanup(); return false; }
    bool releaseStreams()
    {
        bool ok = true;
        if (loaderTouched) {
            if (hw.stopAndRestoreLoader()) loaderTouched = false;
            else ok = false;
        }
        if (iccmaxTouched) {
            if (hw.stopAndRestoreIccmax()) iccmaxTouched = false;
            else ok = false;
        }
        return ok;
    }
    Backend &hw;
    bool attempted = false, saved = false, ready = false;
    bool iccmaxTouched = false, loaderTouched = false, coreTouched = false;
};
}
