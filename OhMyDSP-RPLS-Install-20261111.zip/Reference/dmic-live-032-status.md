# Live Capture Integration 0.3.2

- User confirmed the one-second 0.3.1 recording contains real sound.
- Added explicit LIVE_TEST=1 standalone core build, revision rpl-live-0.3.2.
- Default production and EFI startup remain blocked.
- Live build prepares firmware/ring in software and exposes root-only user client;
  hardware startup happens on a recording request.
- Corrected retained BAR ownership in core preparation and probe bounds.
- Eight offline sanitizer suites passed; core live build and coretest compiled.
- Test script work/test-dmic-live.sh attempts 10-second capture then 3-second
  restart capture, with unload and payload cleanup on exit.
- Administrator-authorized loading was rejected by macOS:
  "Extension with identifiers com.ohmydsp.OhMyDSP not approved to load.
  Please approve using System Settings."
- Artifacts: /private/var/tmp/dmic-live.HGmtb0.
- Subsequently approved 0.3.2 passed the sustained hardware test at
  /private/var/tmp/dmic-live.pQg5KT: 479804 frames over ten seconds and 143896
  frames after restart over three seconds, nonzero stereo PCM, zero faults
  and recoveries. Both stops succeeded and the driver unloaded.
- Temporary daemon/HAL integration enumerated Internal Microphone (DMIC).
  Root CoreAudio recording produced only zero samples.
- A signed user-session recorder (uid 501) requested microphone permission,
  but tccd denied prompting: "CS_PLATFORM_BINARY set but not AppleSigned".
  This is an observed permission failure, not proof that the HAL audio works.
- Existing boot arguments include amfi_get_out_of_my_way=0x1 and amfi=0x80.
  They have not been changed; other installed components may depend on them.
- HAL diagnostics now report read/valid/nonzero frame counts through the daemon
  to distinguish a bridge failure from downstream permission silencing.
- Follow-up /private/var/tmp/dmic-coreaudio.zpi8v1: daemon received HAL stop
  diagnostics read=0, valid=0, signal=0. CoreAudio started the stream but did not
  call ReadInput while the test clients lacked microphone permission.
  This does not validate the HAL data path; retest after normal TCC authorization.
- All temporary HAL/daemon/payload installations removed and kext unloaded.
- A separate candidate config removes only the two global AMFI boot arguments,
  retaining the already-enabled AMFIPass. Candidate is NOT activated: GPU
  compatibility with enabled AMFI is unverified and needs an explicit bounded
  reboot test with rollback. No privacy database edits or TCC bypass performed.
- EFI unchanged. Sleep and playback coexistence remain unverified.

## Authorized Permission Boot Test Applied

- User confirmed proceeding. USB EFI config now removes only
  `amfi_get_out_of_my_way=0x1` and `amfi=0x80`.
- All other parsed configuration fields are identical. AMFIPass remains enabled,
  OhMyDSP remains disabled, no GPU or wireless drivers changed.
- Current USB config SHA256:
  `55d8b5f53d1361c337cf5de41e71cc1db87bdbbde7cf636037a0517ff63404e6`.
- Original SHA256:
  `bf1040b63bc56e04916260c60e9f13df50888a2857a91cecf42947ec609ed347`.
- Original copies: `outputs/config-before-dmic-permission-test.plist` and
  `/Volumes/1401/EFI/OC/config-before-dmic-permission-test.plist`.
- Plist validation and exact structured-difference checks passed; sync completed.
  OpenCore ocvalidate was unavailable. No live NVRAM write or automatic reboot.
- Pending manual boot from the same USB; verify effective arguments and graphics
  before rerunning temporary CoreAudio integration. This is not a microphone fix
  confirmation. If boot/display fails, restore the original backup as config.plist
  from another boot environment.

## Boot Test Failed And Reverted

- User reported a black screen and inability to enter macOS.
- Restored both original AMFI arguments in USB config immediately.
- Restored config SHA256 exactly matches the original backup:
  `bf1040b63bc56e04916260c60e9f13df50888a2857a91cecf42947ec609ed347`.
- Plist syntax check and sync passed. No drivers or other fields changed.
- Do not activate the permission-test candidate again. Boot recovery remains
  pending user confirmation from the restored USB.

## Restored Boot And QuickTime Preview

- Subsequent running system verified original boot arguments and original USB
  configuration SHA256.
- Stock QuickTime preview reached the HAL: daemon diagnostics showed
  read=123904, valid=123904, signal=123803, first=123392, written=124312.
  This confirms nonzero HAL output, not a completed saved recording.
- QuickTime scripting failed to resolve the device name. Removed that lookup
  for a follow-up using the preview-selected default device.
- The follow-up was interrupted; no saved recording confirmed. No test processes
  or installed temporary daemon/HAL/payload remained at the cleanup audit.
