# First macOS RPL DMIC Capture

- Exact runtime revision: rpl-capture-0.3.1.
- Root artifacts: /private/var/tmp/dmic-firmware.eEQfP9.
- Firmware ready, 19/19 topology IPC replies accepted, stereo capture switch ON
  accepted, PCM_PARAMS and TRIG_START/STOP/FREE accepted.
- SD6 tag7, one second capture, LPIB=384320, status=0x20,
  DMA stop confirmed.
- PCM: 384320 bytes, 48040 stereo frames, 1.000833 seconds at 48000 Hz S32LE.
- Nonzero sample count 95877; peak 149662880.
- Exported left RMS -47.28 dBFS, right RMS -47.51 dBFS.
- Local WAV: dmic-capture-031-ioreg.wav.
- Full captured IORegistry: dmic-capture-031-ioreg.plist.
- DSP reset/power-down succeeded (ADSPCS=303), driver unloaded.
- This proves nonzero hardware PCM capture, not intelligible speech, sustained
  capture, CoreAudio device integration, playback coexistence or sleep safety.
- User listening confirmation is pending. No production driver or HAL installed.
- EFI remains unchanged and the production startup gate stays closed.
