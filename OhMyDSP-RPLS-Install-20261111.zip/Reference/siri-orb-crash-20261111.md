# Siri orb failure: current evidence

## Observed after HAL 0.3.4

The user reports that Siri still has no orb, while Control Center shows a
microphone indicator. UID routing correction did not resolve this symptom.

At 18:02:09 CoreSpeech selects com.ohmydsp.InternalMicrophone and configures
an AudioQueue recording engine at 48000 Hz. A successful recording-start
completion is not present in the inspected logs.

SiriNCService crashes repeatedly (18:02:10, 18:02:19, 18:02:50).
The 18:02:50 crash report identifies SIGABRT on the main thread:

    __assert_rtn
    MTLReportFailure
    MetalPerformanceShaders.MPSImage
    -[SUICOrbView _drawSiriFrame:]

At 18:02:49.295 the NVMTLDriver log reports device loss during the first
texture-upload submission, with zero compute dispatches recorded:

    VK_ERROR_DEVICE_LOST (-4)
    nvmtl_vk_image_write_region_level_layer
    replaceRegion:slice: upload FAILED

At 18:02:49.296 SiriNCService reports:

    -[SUICOrbView _loadAssets] Error creating Siri textures

The crash images include /Library/GPUBundles/NVMTLDriver.bundle and its
Vulkan backend. This is direct evidence of a graphics failure preventing
the orb from displaying. It does not prove that all microphone/Siri
capture problems are resolved, nor explain all historical route differences.

## Evidence paths

- /Users/johnwu/Library/Logs/DiagnosticReports/SiriNCService-2026-11-11-180250.ips
- /Users/johnwu/Library/Containers/com.apple.SiriNCService/Data/tmp/nvmtl-fault-2391.txt
- outputs/assistantd-siri-hang.sample.txt
- outputs/corespeechd-siri-hang.sample.txt

## Changes in this investigation

Read existing logs, crash reports and process stacks; no audio stream
started, no EFI/AMFI/GPU changes, no microphone authorization reset.
Current upstream driver app profiles contain no Siri-specific compatibility
profile. No unverified global graphics knob was applied.

Next repair work needs to address the first texture-upload device loss
in NVMTL/NVK. Successful Siri display and actual capture remain unverified.

## User correction

The user confirms that selecting Apple's built-in microphone displays the
Siri orb, while selecting DMIC does not. Therefore the graphics crash alone
does not establish a standalone GPU-driver root cause. A route-dependent
audio/graphics interaction or audio setup failure remains possible.
Do not replace graphics drivers on this evidence. The inspected current
boot logs contain the failing DMIC invocation, but no corresponding fresh
successful built-in invocation for a matched comparison.

## Same-boot comparison at 18:09

The newly inspected CoreAudio logs refine the route attribution:

- 18:09:24.848: DMIC StartIO succeeds for client PID 1425. This is not
  evidence that Siri opened DMIC.
- 18:09:27.322: CoreAudio changes the default input to
  AppleHDAEngineInput:1F,3,0,1,0:1.
- 18:09:27.422: DMIC stops cleanly. Its summary is 122368 frames read,
  122368 valid and 122267 nonzero frames. No independent recording was
  started by this investigation.
- 18:09:30.116 and 18:09:32.914: SiriNCService still fails on the first
  texture upload with VK_ERROR_DEVICE_LOST. Both failures occur AFTER
  the default input switched to AppleHDA and AFTER DMIC IO stopped.
- 18:09:35.823: a fresh SiriNCService PID 2906 initializes SUICOrbView.
  This instance proceeds to draw successfully.
- 18:09:36.577: CoreSpeech updates its cached route to AppleHDA.
- 18:09:36.701: assistantd reports recording started successfully.
- 18:09:36.758: CoreSpeech receives its first AppleHDA audio buffer.

The failing Siri invocations do not contain a new AudioQueue recording
start request. An Invalid/StreamInit state alone is therefore not proof
of DMIC preparation failure. Graphics failure precedes the missing
recording start in these invocations.

This comparison disproves the narrower claim that all observed orb
crashes occurred while DMIC was the system default or actively capturing.
It does not rule out an effect of prior DMIC activity, a stale CoreSpeech
route, or another shared driver interaction. It does not establish that
Siri capture through DMIC works. No speculative HAL, EFI or GPU change
was applied.
