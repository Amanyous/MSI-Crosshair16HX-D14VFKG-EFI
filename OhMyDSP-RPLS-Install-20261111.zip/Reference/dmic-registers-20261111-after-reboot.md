# Authorized hardware diagnostic after reboot

The read-only standalone driver loaded successfully, completed its probe, and
was unloaded. No firmware, DMA or power-up implementation was linked.
Artifacts: /private/var/tmp/dmic-readonly.GETwYB (root-owned).

## Observed Registers

```text
8086:7a50 command=0406 PM=D0 PGCTL=00000000 CGCTL=00fb09ff
BAR0 physical=4017130000 length=4000
GCAP=9701 inputs=7 outputs=9 GCTL=00000101
INTCTL=c0000000 INTSTS=00000000
SD0 CTLSTS=20140000 CBL=00030000 BDL=00000000:2e2ca000
SD7 CTLSTS=00140000 CBL=00060000 BDL=00000000:2e2c9000
SD1..6,SD8..15 CTLSTS=00040000 CBL=0 BDL=0
PP capability=0800 PPCTL=40000000
SPIB capability=0700 SPIB control=00000000
EM2=84806000 LTRP=280800a9
BAR4 physical=4017000000 length=100000
ADSPCS=00000303 ADSPIC=00000000 ADSPIS=00000000
HIPCTDR/HIPCTDA/HIPCTDD/HIPCIDR/HIPCIDA/HIPCIDD/HIPCCTL=0
SRAM intentionally not read
```

## Consequences

- DSP cores were reset/stalled and powered off at the instant sampled.
- AppleHDA-configured SD0 and SD7 must not be borrowed, even when RUN is clear.
- Current planner selects capture SD6, ICCMAX SD5 and loader SD15.
- Capture tag must be 7 and loader playback tag must be 9, matching direction-relative
  descriptor indexing in the locally retained Linux hda_dsp_stream_init source.
- Corrected arbitrary tag allocation and added snapshot-based RPL capture cleanup.
- Eight offline ASan/UBSan suites and the core-lilu build passed after these fixes.
  Core build log: outputs/dmic-build-after-registers-20261111.log.
- A snapshot is not a controller ownership lock. AppleHDA allocation and sleep
  races remain unresolved; the firmware/capture startup gate remains closed.
- No successful macOS recording yet. This is diagnostic progress, not a working mic.
- USB config SHA256 remains bf1040b63bc56e04916260c60e9f13df50888a2857a91cecf42947ec609ed347.
