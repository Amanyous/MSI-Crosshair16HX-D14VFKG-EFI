# OhMyDSP RPL-S 完整驱动备份

打包日期：2026-11-11。适用对象：本机 MSI Crosshair16 HX D14VFKG、
Intel Core i7-14700HX、Intel 8086:7a50 数字麦克风。
这是当前部署状态的备份，不是已解决所有问题的正式发布版。

## 内容

- `EFI/OC/Kexts/OhMyDSP.kext`：从当前 U 盘 EFI 复制的核心 0.3.3，
  revision 为 `rpl-live-0.3.3`。
- `System/Library/Audio/Plug-Ins/HAL/OhMyDSP.driver`：当前系统 HAL 0.3.4。
- `System/Library/Application Support/OhMyDSP/`：当前 daemon、SOF 固件及
  RPL-S DMIC IPC 拓扑。
- `System/Library/LaunchDaemons/com.ohmydsp.daemon.plist`：当前启动服务配置。
- `OpenCore-Kernel-Add.json`：当前 EFI 中 OhMyDSP 单条配置，供恢复时参考。
  不包含整机 config.plist，不能用它覆盖 OpenCore 主配置。
- `Source/OhMyDSP-main/`：本地修改后的完整源码、上游文档和许可证；
  不包含历史 build 目录及临时 local 测试程序。
- `Source/dmic-uid-regression.c`：HAL UID 路由离线回归检查源码。
- `Reference/`：构建、采集及 Siri 排查记录；记录描述不同时间的状态，
  以本说明的当前状态为准。
- `Payload-Provenance.txt`：固件和拓扑来源、哈希及授权说明。
- `SHA256SUMS.txt`：包内文件校验清单。

## 当前状态

核心 0.3.3 已在本机启动后进入 CaptureSessionReady。已有用户确认的
真实麦克风采样，以及 CoreAudio 客户端读取非零音频的记录。
HAL 0.3.4 修复了错误认领其他设备 UID 的问题。

用户最新反馈：数字麦克风在本机可用。
已知 bug：Siri 需要先将输入切换到“内建麦克风”，再切换回
“Internal Microphone (DMIC)”数字麦克风驱动才能使用。
这是临时切换方法，不表示底层问题已修复；此前也观察到 Siri 球体纹理上传崩溃。
第三方应用授权、睡眠唤醒、AppleHDA 共享控制器协调仍需验证。
本包不是通用机型驱动，也不是双击安装的 pkg；请按下文恢复安装步骤操作。
Reference 中保留历史排查记录，当前可用状态以本节最新用户反馈为准。

## 恢复安装

本次打包不执行安装、重启、录音或修改 EFI。
以下步骤仅供以后恢复本机时使用：

1. 先备份目标 EFI 和系统中已有的同名 OhMyDSP 文件。
2. 将包内 kext 放进目标 EFI 的 `EFI/OC/Kexts/`，按
   `OpenCore-Kernel-Add.json` 添加或核对对应 Kernel/Add 条目。
   不要重复添加，不要覆盖整个 config.plist。
3. 系统组件必须同时恢复。打开终端进入解压后的包目录，执行：

```sh
sudo mkdir -p "/Library/Application Support/OhMyDSP"
sudo mkdir -p "/Library/Audio/Plug-Ins/HAL"
sudo launchctl bootout system/com.ohmydsp.daemon 2>/dev/null
sudo ditto "System/Library/Application Support/OhMyDSP" "/Library/Application Support/OhMyDSP"
sudo ditto "System/Library/Audio/Plug-Ins/HAL/OhMyDSP.driver" "/Library/Audio/Plug-Ins/HAL/OhMyDSP.driver"
sudo ditto "System/Library/LaunchDaemons/com.ohmydsp.daemon.plist" "/Library/LaunchDaemons/com.ohmydsp.daemon.plist"
sudo chown -R root:wheel "/Library/Application Support/OhMyDSP" "/Library/Audio/Plug-Ins/HAL/OhMyDSP.driver"
sudo chown root:wheel "/Library/LaunchDaemons/com.ohmydsp.daemon.plist"
sudo chmod -R go-w "/Library/Application Support/OhMyDSP" "/Library/Audio/Plug-Ins/HAL/OhMyDSP.driver"
sudo chmod 755 "/Library/Application Support/OhMyDSP/ohmydspd"
sudo chmod 644 "/Library/LaunchDaemons/com.ohmydsp.daemon.plist"
sudo launchctl bootstrap system "/Library/LaunchDaemons/com.ohmydsp.daemon.plist"
sudo killall coreaudiod
```

停止尚未运行的 daemon 时，bootout 可以返回非零；其他安装错误应先处理。
音频服务重载会短暂中断声音。EFI kext 的变动需以后手动重启生效；
刚开机时核心默认等待约 30 秒再准备硬件。

保留本机现有 AMFI 参数及显卡、无线驱动；之前删除 AMFI 参数曾导致黑屏。
本包没有完整 EFI，也不包含显卡或无线驱动。

## 回退

将 Kernel/Add 中 OhMyDSP 条目 Enabled 改为 false，并恢复安装前备份的
系统同名组件。需要停用用户态服务时执行：

```sh
sudo launchctl bootout system/com.ohmydsp.daemon
```

要完全撤下 HAL，可将 `/Library/Audio/Plug-Ins/HAL/OhMyDSP.driver`
移到单独的备份目录，再重载 coreaudiod；EFI 核心停用以后手动重启生效。
不要删除其他音频驱动或修改其他启动参数。

## 从源码构建

在 `Source/OhMyDSP-main` 内执行：

```sh
make -C ohmydsp LIVE_TEST=1 VERSION=0.3.3
make -C ohmydsp/userspace
```

产物分别在 `ohmydsp/build/live-test/` 和 `ohmydsp/userspace/build/`。
本机 RPL-S 恢复请以上述系统组件路径为准；上游
`tools/install-userspace.sh` 的默认 CNL 固件命名不适合直接用于此包。

## 校验

在本包目录执行：

```sh
shasum -a 256 -c SHA256SUMS.txt
```
